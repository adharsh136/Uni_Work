package studentapi;

/** Exception indicating that the API query timed out. */
public class QueryTimedOutException extends Exception {}
